package com.unipar.ordenacaovetores;

import java.util.Scanner;

public class OrdenacaoVetores {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int tamanho = 0;
        int selecao = 0;

        System.out.println("Qual o tamanho do vetor? ");
        tamanho = scan.nextInt(); //salvando o tamanho do vetor

        int[] vetor = new int[tamanho]; //declarando o tamanho do vetor com o que o usuario escreveu

        System.out.println("\nDigite os numeros do VETOR: ");
        for (int i = 0; i < tamanho; i++) {
            vetor[i] = scan.nextInt();
        }

        System.out.println("\nQual metodo deseja ordenar? "
                + "(1)-Ordenacao por INSERCAO"
                + " || (2)-Ordenacao por SELECAO"
                + " || (3)-Ordenacao por BOLHA");
        selecao = scan.nextInt();

        System.out.println("\nOs numeros do VETOR: ");
        for (int i = 0; i < tamanho; i++) {
            System.out.println(vetor[i]);
        }

        if (selecao == 1) {                                 // INSERCAO
            for (int i = 0; i < tamanho; i++) {
                int posicaoMenor = i;

                for (int j = i + 1; j < tamanho; j++) {
                    if (vetor[j] < vetor[posicaoMenor]) {
                        posicaoMenor = j;
                    }
                }
                if (posicaoMenor != i) {
                    int aux = vetor[i];
                    vetor[i] = vetor[posicaoMenor];
                    vetor[posicaoMenor] = aux;
                }
            }
            System.out.println("\nOs numeros do VETOR ordenados: ");
            for (int i = 0; i < tamanho; i++) {
                System.out.println(vetor[i]);
            }
        }

        if (selecao == 2) {                                 // SELECAO
            for (int i = 0; i < tamanho - 1; i++) {
                int posicaoMenor = i;

                for (int j = i + 1; j < tamanho; j++) {
                    if (vetor[j] < vetor[posicaoMenor]) {
                        posicaoMenor = j;
                    }
                }

                if (posicaoMenor != i) {
                    int aux = vetor[i];
                    vetor[i] = vetor[posicaoMenor];
                    vetor[posicaoMenor] = aux;
                }
            }

            System.out.println("\nOs numeros do VETOR ordenados: ");
            for (int i = 0; i < tamanho; i++) {
                System.out.println(vetor[i]);
            }
        }

        if (selecao == 3) {                                // BOLHA
            boolean houveTroca = true;

            while (houveTroca) {
                houveTroca = false;

                for (int i = 0; i < vetor.length - 1; i++) {
                    if (vetor[i] > vetor[i + 1]) {
                        int aux = vetor[i];
                        vetor[i] = vetor[i + 1];
                        vetor[i + 1] = aux;
                        houveTroca = true;
                    }
                }
            }
            System.out.println("\nOs numeros do VETOR ordenados: ");
            for (int i = 0; i < tamanho; i++) {
                System.out.println(vetor[i]);
            }
        }

    }
}
